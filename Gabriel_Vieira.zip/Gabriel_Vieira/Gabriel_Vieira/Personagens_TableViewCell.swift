//
//  TableViewCell.swift
//  Gabriel_Vieira
//
//  Created by COTEMIG on 22/08/23.
//

import UIKit
import Kingfisher

class Personagens_TableViewCell: UITableViewCell {
    
  
    @IBOutlet weak var Nome: UILabel!
    
    
    @IBOutlet weak var ImageView: UIImageView!
 
    @IBOutlet weak var sobreNome: UILabel!
    
    
   
    
    func Setup(_ personagem : Personagem) {
        Nome.text = personagem.strMeal
        sobreNome.text = personagem.strArea
        ImageView.kf.setImage(with: URL(string: personagem.strMealThumb)!)
    }
}
