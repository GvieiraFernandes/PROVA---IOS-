//
//  ViewController.swift
//  Gabriel_Vieira
//
//  Created by COTEMIG on 22/08/23.
//

import UIKit
import Alamofire
import Kingfisher


class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var TableView: UITableView!
    
    var ListaPersonagem : [Personagem] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TableView.dataSource = self
        
        AF.request("https://www.themealdb.com/api/json/v1/1/search.php?f=a").responseDecodable(of:Results.self) { response in
            if let personagens = response.value {
                self.ListaPersonagem = personagens.meals
                self.TableView.reloadData()
                
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ListaPersonagem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let personagem = ListaPersonagem[indexPath.row]
        if let Cell =
            tableView.dequeueReusableCell(withIdentifier: "PersonagemCell", for: indexPath) as?
            Personagens_TableViewCell {
            Cell.Setup(personagem)
            return Cell
        }
        else {
            return UITableViewCell()
        }
    }
    
   
    @IBAction func salvar(_ sender: Any) {
        if let data = try? JSONEncoder().encode(ListaPersonagem) {
            UserDefaults.standard.set(data, forKey: "Gabriel")
        }
    }
    @IBAction func apagar(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "Gabriel")
    }
}

struct Results: Codable {
    let meals: [Personagem]
}

struct Personagem: Codable {
    let strMeal: String
    let strArea: String
    let strMealThumb: String
}
